const { EmbedBuilder, PermissionFlagsBits, ChannelType, ActionRowBuilder, MessageFlags, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createTranscript } = require('discord-html-transcripts');
const TicketSetup = require('../../Schemas/TicketSetup');
const TicketSchema = require('../../Schemas/Ticket');
const config = require('../../ticketconfig');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        const { guild, member, customId, channel } = interaction;

        if (interaction.isStringSelectMenu() && customId === 'ticket-dropdown') {
            const docs = await TicketSetup.findOne({ GuildID: guild.id });
            if (!docs) {
                return interaction.reply({ embeds: [new EmbedBuilder().setDescription('Ticket system is not set up.').setColor('Red')], flags: MessageFlags.Ephemeral });
            }

            const findTicket = await TicketSchema.findOne({ GuildID: guild.id, OwnerID: member.id });
            if (findTicket) {
                return interaction.reply({ embeds: [new EmbedBuilder().setDescription('You already have an open ticket.').setColor('Red')], flags: MessageFlags.Ephemeral });
            }

            const ticketId = Math.floor(Math.random() * 9000) + 10000;

            try {
                const ticketChannel = await guild.channels.create({
                    name: `${config.ticketName}-${ticketId}`,
                    type: ChannelType.GuildText,
                    parent: docs.Category,
                    permissionOverwrites: [
                        {
                            id: guild.roles.everyone.id,
                            deny: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                        },
                        {
                            id: docs.Handlers,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels],
                        },
                        {
                            id: member.id,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                        },
                    ],
                });

                await TicketSchema.create({
                    GuildID: guild.id,
                    OwnerID: member.id,
                    MembersID: [member.id],
                    TicketID: ticketId,
                    ChannelID: ticketChannel.id,
                    Locked: false,
                    Claimed: false,
                });

                await ticketChannel.setTopic(`${config.ticketDescription} <@${member.id}>`).catch(error => { return; });

                const embed = new EmbedBuilder()
                    .setTitle(config.ticketMessageTitle)
                    .setDescription(config.ticketMessageDescription)
                    .setColor(client.config.embed);

                const buttons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('ticket-close')
                        .setLabel(config.ticketClose)
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji(config.ticketCloseEmoji),
                    new ButtonBuilder()
                        .setCustomId('ticket-lock')
                        .setLabel(config.ticketLock)
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji(config.ticketLockEmoji),
                    new ButtonBuilder()
                        .setCustomId('ticket-unlock')
                        .setLabel(config.ticketUnlock)
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji(config.ticketUnlockEmoji),
                    new ButtonBuilder()
                        .setCustomId('ticket-manage')
                        .setLabel(config.ticketManage)
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji(config.ticketManageEmoji),
                    new ButtonBuilder()
                        .setCustomId('ticket-claim')
                        .setLabel(config.ticketClaim)
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji(config.ticketClaimEmoji),
                );

                await ticketChannel.send({ embeds: [embed], components: [buttons] }).catch(error => { return; });

                const ticketMessage = new EmbedBuilder()
                    .setDescription(`${config.ticketCreate} <#${ticketChannel.id}>`)
                    .setColor('Green');

                await interaction.reply({
                    embeds: [ticketMessage],
                    flags: MessageFlags.Ephemeral,
                });

                switch (interaction.values[0]) {
                    case 'support':
                        await ticketChannel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setTitle('Support Ticket')
                                    .setDescription('A support ticket has been created. Please describe your issue in detail.')
                                    .setColor('Blue'),
                            ],
                        });
                        break;

                    case 'report':
                        await ticketChannel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setTitle('Report Ticket')
                                    .setDescription('A report ticket has been created. Please provide details about the issue or user you are reporting.')
                                    .setColor('Red'),
                            ],
                        });
                        break;

                    case 'other':
                        await ticketChannel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setTitle('Other Inquiry')
                                    .setDescription('An inquiry ticket has been created. Please describe your request or question.')
                                    .setColor('Yellow'),
                            ],
                        });
                        break;
                }
            } catch (err) {
                console.error(err);
                return interaction.reply({ content: 'An error occurred while creating the ticket.', flags: MessageFlags.Ephemeral });
            }
        }

        if (interaction.isButton()) {
            const docs = await TicketSetup.findOne({ GuildID: guild.id });
            if (!docs) return;

            const errorEmbed = new EmbedBuilder().setColor('Red').setDescription(config.ticketError);
            if (!guild.members.me.permissions.has((r) => r.id === docs.Handlers)) {
                return interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral }).catch(error => { return; });
            }

            const data = await TicketSchema.findOne({ GuildID: guild.id, ChannelID: channel.id });
            if (!data) return;

            switch (customId) {
                case 'ticket-close':
                    await handleCloseTicket(interaction, member, data);
                    break;

                case 'ticket-lock':
                    await handleLockTicket(interaction, member, data);
                    break;

                case 'ticket-unlock':
                    await handleUnlockTicket(interaction, member, data);
                    break;

                case 'ticket-claim':
                    await handleClaimTicket(interaction, member, data);
                    break;

                case 'ticket-manage':
                    await handleManageTicket(interaction, member, data);
                    break;

                case 'ticket-reopen':
                    await handleReopenTicket(interaction, member, data);
                    break;

                case 'ticket-delete':
                    await handleDeleteTicket(interaction, member, data);
                    break;

                case 'ticket-transcript':
                    await handleSendTranscript(interaction, member, data);
                    break;
            }
        }
    },
};

async function handleCloseTicket(interaction, member, data) {
   
    await interaction.deferUpdate();

    const reason = await getReason(interaction, member);
    if (!reason) return;

    const transcript = await createTranscript(interaction.channel, {
        limit: -1,
        returnType: 'attachment',
        saveImages: true,
        poweredBy: false,
        filename: `${config.ticketName}-${data.TicketID}.html`,
    });

    const closingTicketEmbed = new EmbedBuilder()
        .setTitle('Ticket Closed')
        .setDescription(`This ticket was closed by <@${member.id}> for the following reason: ${reason}`)
        .setColor('Red');

    const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('ticket-reopen')
            .setLabel('Reopen Ticket')
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId('ticket-delete')
            .setLabel('Delete Ticket')
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId('ticket-transcript')
            .setLabel('Send Transcript')
            .setStyle(ButtonStyle.Secondary)
    );

    await interaction.channel.send({ embeds: [closingTicketEmbed], components: [buttons] });

    const ticketOwner = await interaction.guild.members.fetch(data.OwnerID);
    await ticketOwner.send({ content: `Your ticket has been closed. Reason: ${reason}`, files: [transcript] });
}

async function handleReopenTicket(interaction, member, data) {
    await interaction.deferUpdate();
    await TicketSchema.updateOne({ ChannelID: interaction.channel.id }, { Locked: false, Claimed: false });
    
    const reopenedEmbed = new EmbedBuilder()
        .setTitle('Ticket Reopened')
        .setDescription(`This ticket has been reopened by <@${member.id}>.`)
        .setColor('Green');

    await interaction.channel.send({ embeds: [reopenedEmbed] });
}

async function handleDeleteTicket(interaction, member, data) {
    await interaction.deferUpdate();
    await interaction.channel.send('Deleting the ticket channel...');
    await TicketSchema.findOneAndDelete({ GuildID: interaction.guild.id, ChannelID: interaction.channel.id });
    await interaction.channel.delete();
}

async function handleSendTranscript(interaction, member, data) {
    await interaction.deferUpdate();
    const transcript = await createTranscript(interaction.channel, {
        limit: -1,
        returnType: 'attachment',
        saveImages: true,
        poweredBy: false,
        filename: `${config.ticketName}-${data.TicketID}.html`,
    });

    await interaction.user.send({ content: 'Here is your ticket transcript:', files: [transcript] });
    await interaction.channel.send('The transcript has been sent to your DMs.');
}

async function handleLockTicket(interaction, member, data) {
    await TicketSchema.updateOne({ ChannelID: interaction.channel.id }, { Locked: true });
    await interaction.followUp({ content: 'The ticket has been locked.', flags: MessageFlags.Ephemeral });
}

async function handleUnlockTicket(interaction, member, data) {
    await TicketSchema.updateOne({ ChannelID: interaction.channel.id }, { Locked: false });
    await interaction.followUp({ content: 'The ticket has been unlocked.', flags: MessageFlags.Ephemeral });
}

async function handleClaimTicket(interaction, member, data) {
    await TicketSchema.updateOne({ ChannelID: interaction.channel.id }, { Claimed: true, ClaimedBy: member.id });
    await interaction.followUp({ content: 'You have claimed this ticket.', flags: MessageFlags.Ephemeral });
}

async function handleManageTicket(interaction, member, data) {
    await interaction.followUp({ content: 'Ticket management options will be displayed here.', flags: MessageFlags.Ephemeral });
}

async function getReason(interaction, member) {
    await interaction.followUp({ content: 'Please provide a reason for closing this ticket:', flags: MessageFlags.Ephemeral });

    const filter = response => response.author.id === member.id;
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 30000 });

    return new Promise((resolve) => {
        collector.on('collect', message => {
            resolve(message.content);
            collector.stop();
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.followUp({ content: 'You did not provide a reason in time. The ticket will not be closed.', flags: MessageFlags.Ephemeral });
                resolve(null);
            }
        });
    });
}