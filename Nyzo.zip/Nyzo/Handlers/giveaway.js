const { GiveawaysManager: gw } = require("discord-giveaways");
const giveawayModel = require("../Schemas/giveawayschema.js");

module.exports = class GiveawaysManager extends gw {
  async getAllGiveaways() {
    return await giveawayModel.find().lean().exec();
  }

  async saveGiveaway(messageId, giveawayData) {
    return await giveawayModel.create(giveawayData);
  }

/*
true
599104
teshou
29648
203069
1747677219
9532e84957c991a3d65f128172a7c51f
*/


  async editGiveaway(messageId, giveawayData) {
    return await giveawayModel
      .updateOne({ messageId }, giveawayData, { omitUndefined: true })
      .exec();
  }

  async deleteGiveaway(messageId) {
    return await giveawayModel.deleteOne({ messageId }).exec();
  }
};
