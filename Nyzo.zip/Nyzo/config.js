/**
 * Configuration settings for the Razor bot.
 * 
 * This file contains essential settings for bot functionality, 
 * including command prefixes, channel IDs, and API keys.
 * Ensure to fill in the required fields before deploying the bot.
 */
const config = {
  // Color for embedded bot messages
  embed: "#ff434e",
  // Command prefix for bot commands
  prefix: "!",
  // Channel ID for logging errors (Development Server)
  logchannel: "1370402855944720439",
  // Channel ID for reporting bugs (Development Server)
  bugreport: "1370402855944720439",
  // Channel ID for user feedback (Development Server)
  feedback: "1370402855944720439",
  // Channel ID for receiving bot suggestions (Development Server)
  botsuggestions: "1370402855944720439",
  // Your Discord User ID for development purposes
  developerid: "1323256236233195570",
  // Your Discord Bot ID for API interactions
  clientID: "1374087184662921236",
  // API key for image generation (Obtain from https://discord.gg/QprAy5WWWQ)
  imagegenapi: "rsnlabs_de825a7b40e9b5233781ae029b78ff",
  // API key for Gemini services (Obtain from https://ai.google.dev/)
  gemini_api: "AIzaSyDn8fvWk50BED93K1bLPMAv99y79o0n5fg",

  // Spotify API credentials
  // Obtain your Spotify Client ID and Client Secret from the Spotify Developer Portal: 
  // https://developer.spotify.com/dashboard/
  SpotifyClientID: "65539857701a44b088cad186da058df2",
  SpotifyClientSecret: "50a015534b7e4be0bf34c57b105f839e",

  // Lavalink server configuration
  lavalink: {
    name: `Razor Node`,
    url: `lava.inzeworld.com:3128`,
    auth: "saher.inzeworld.com",
    secure: false,
  },
};

module.exports = config;